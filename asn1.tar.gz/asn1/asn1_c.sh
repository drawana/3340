#!/bin/sh
javac MixedSort.java
java MixedSort $1 $2
