#!/bin/sh
javac InsertionSort.java
java InsertionSort $1

