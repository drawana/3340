#!/bin/sh
javac MergeSort.java
java MergeSort $1
