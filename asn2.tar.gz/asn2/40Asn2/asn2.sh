#!/bin/sh
javac src/CC_Finder.java src/uandf.java src/TreeNode.java
java src.CC_Finder girl.txt
